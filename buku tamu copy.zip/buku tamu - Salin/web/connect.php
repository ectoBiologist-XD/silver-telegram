<?php
$host = 'localhost';
$username = 'root';
$password = '';
$db = 'buku_tamu';
$conn = mysqli_connect($host, $username, $password, $db);

?>