<?php
session_start();
include('connect.php');

if (!isset($_SESSION['admin_panel'])) {
    header("Location: login.php");
    exit();
}

// Samakan zona waktu sesi MySQL dengan WIB supaya "hari ini" akurat
mysqli_query($conn, "SET time_zone = '+07:00'");

// Total orang yang terdaftar di tabel siswa + guru + umum
$q_total = mysqli_query($conn, "
    SELECT
        (SELECT COUNT(*) FROM siswa) +
        (SELECT COUNT(*) FROM guru) +
        (SELECT COUNT(*) FROM umum) AS total
");
$total_master = (int) mysqli_fetch_assoc($q_total)['total'];

// Tamu unik yang pernah mengisi buku tamu
$q_sudah = mysqli_query($conn, "
    SELECT COUNT(*) AS total
    FROM (SELECT DISTINCT role, user_id FROM data_tamu) AS t
");
$sudah_terdaftar = (int) mysqli_fetch_assoc($q_sudah)['total'];

// Yang belum pernah mengisi buku tamu
$belum_terdaftar = max(0, $total_master - $sudah_terdaftar);

// Kunjungan hari ini
$q_hari_ini = mysqli_query($conn, "
    SELECT COUNT(*) AS total FROM data_tamu WHERE DATE(`datetime`) = CURDATE()
");
$hari_ini = (int) mysqli_fetch_assoc($q_hari_ini)['total'];

// Data tabel: gabungkan data_tamu dengan tabel siswa/guru/umum sesuai role
$data = mysqli_query($conn, "
    SELECT
        d.id,
        d.`datetime`,
        d.role,
        COALESCE(s.nama_siswa, g.nama_guru, u.nama) AS nama,
        COALESCE(CAST(s.nisn AS CHAR), CAST(g.nip AS CHAR), u.email) AS identitas
    FROM data_tamu d
    LEFT JOIN siswa s ON d.role = 'siswa' AND s.id = d.user_id
    LEFT JOIN guru  g ON d.role = 'guru'  AND g.id = d.user_id
    LEFT JOIN umum  u ON d.role = 'umum'  AND u.id = d.user_id
    ORDER BY d.`datetime` DESC
");
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Buku Tamu</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body class="dash-body">
    <nav>
        <h2 class="title-dash">ADMIN PANEL</h2>
        <a href="logout.php" class="logout">
            <span class="nav-navi">LOG OUT</span>
        </a>
    </nav>

    <div class="parent-dash">
        <aside class="side-panel">
            <a href="dashboard_admin.php" class="side-link active">Dashboard</a>
            <a href="#tabelDatabase" class="side-link">Data Tamu</a>
        </aside>

        <main class="infos-parent">
            <div class="label-data">
                <div class="icon"><img src="../assets/img/menu_dark.png" alt=""></div>
                <h2 class="label">Statistik</h2>
            </div>

            <div class="statistik">
                <div class="card-statistik">
                    <h2>Total Tamu yang Telah Terdaftar</h2>
                    <h3 class="counter"><?= $sudah_terdaftar ?></h3>
                </div>
                <div class="card-statistik">
                    <h2>Total Tamu yang Belum Terdaftar</h2>
                    <h3 class="counter"><?= $belum_terdaftar ?></h3>
                </div>
                <div class="card-statistik">
                    <h2>Total Tamu yang Terdaftar Hari ini</h2>
                    <h3 class="counter"><?= $hari_ini ?></h3>
                </div>
            </div>

            <div class="label-data">
                <div class="icon"><img src="../assets/img/database.png" alt=""></div>
                <h2 class="label">buku_tamu Database</h2>
            </div>

            <div class="tabel-database" id="tabelDatabase">
                <table>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>NISN / NIP / Email</th>
                            <th>Role</th>
                            <th>Waktu Kunjungan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($data && mysqli_num_rows($data) > 0): $no = 1; ?>
                            <?php while ($row = mysqli_fetch_assoc($data)): ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= htmlspecialchars($row['nama'] ?? '(data tidak ditemukan)') ?></td>
                                    <td><?= htmlspecialchars($row['identitas'] ?? '-') ?></td>
                                    <td>
                                        <span class="badge badge-<?= htmlspecialchars($row['role']) ?>">
                                            <?= htmlspecialchars(ucfirst($row['role'])) ?>
                                        </span>
                                    </td>
                                    <td><?= date('d M Y, H:i', strtotime($row['datetime'])) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="empty-msg">Belum ada data.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>

</html>