<?php
session_start();
include('connect.php');
if (isset($_POST['submit_data'])) {
    $role = $_POST['role'];
    $data = $_POST['data'];

    if ($role === 'umum' and $data === 'admin123@gmail.com') {
        $_SESSION['admin_panel'] = true;
        header("Location: dashboard_admin.php");
        exit();
    } else if ($role === 'siswa') {
        $syntax = "SELECT * FROM siswa WHERE nisn = '$data'";
        $query = mysqli_query($conn, $syntax);
        if (mysqli_num_rows($query) == 1) {
            $info = mysqli_fetch_assoc($query);
            $syntax_dupes = "SELECT * FROM data_tamu WHERE user_id = '{$info['id']}' AND role = '$role'";
            $query_dupes = mysqli_query($conn, $syntax_dupes);
            if (mysqli_num_rows($query_dupes) == 1) {
                $duped_success = true;
            } else {
                $syntax_insert = "INSERT INTO data_tamu (user_id, role) VALUES ('{$info['id']}' , '$role')";
                $insert = mysqli_query($conn, $syntax_insert);
                $success = true;
            }
        } else {
            $error = true;
        }
    } else if ($role === 'guru') {
        $syntax = "SELECT * FROM guru WHERE nip = '$data'";
        $query = mysqli_query($conn, $syntax);
        if (mysqli_num_rows($query) == 1) {
            $info = mysqli_fetch_assoc($query);
            $syntax_dupes = "SELECT * FROM data_tamu WHERE user_id = '{$info['id']}' AND role = '$role'";
            $query_dupes = mysqli_query($conn, $syntax_dupes);
            if (mysqli_num_rows($query_dupes) == 1) {
                $duped_success = true;
            } else {
                $syntax_insert = "INSERT INTO data_tamu (user_id, role) VALUES ('{$info['id']}' , '$role')";
                $insert = mysqli_query($conn, $syntax_insert);
                $success = true;
            }
        } else {
            $error = true;
        }
    } else if ($role === 'umum') {
        $syntax = "SELECT * FROM umum WHERE email = '$data'";
        $query = mysqli_query($conn, $syntax);
        if (mysqli_num_rows($query) == 1) {
            $info = mysqli_fetch_assoc($query);
            $syntax_dupes = "SELECT * FROM data_tamu WHERE user_id = '{$info['id']}' AND role = '$role'";
            $query_dupes = mysqli_query($conn, $syntax_dupes);
            if (mysqli_num_rows($query_dupes) == 1) {
                $duped_success = true;
            } else {
                $syntax_insert = "INSERT INTO data_tamu (user_id, role) VALUES ('{$info['id']}' , '$role')";
                $insert = mysqli_query($conn, $syntax_insert);
                $success = true;
            }
        } else {
            $error = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
</head>

<body>
    <div class="parent">
        <div class="login-box">
            <h2 class="title">Buku Tamu</h2>

            <p class="subtitle">
                Silakan isi data untuk mencatat kunjungan Anda
            </p>
            <form method="post">
                <?php if (isset($success)): ?>
                    <div class="success-msg">Data berhasil untuk disimpan!</div>
                <?php elseif (isset($duped_success)): ?>
                    <div class="success-msg">Data telah disimpan.</div>
                <?php elseif (isset($error)): ?>
                    <div class="error-msg">Terjadi kesalahan.</div>
                <?php endif; ?>
                <label for="role">ROLE</label>

                <select id="role" name="role" class="dropdown-role">
                    <option value="siswa">SISWA</option>
                    <option value="guru">GURU</option>
                    <option value="umum">UMUM</option>
                </select>

                <label for="pilihan" id="label-pilihan">NISN</label>
                <input type="text" id="pilihan" placeholder="Ketik NISN di sini..." required name="data"><br>
                <input type="submit" value="Submit" name="submit_data" class="login">
            </form>
        </div>
    </div>
    <script>
        const role = document.querySelector('.dropdown-role');
        const labelPilihan = document.getElementById('label-pilihan');
        const input = document.getElementById('pilihan');

        role.addEventListener('change', function() {
            const selectedRole = role.value;

            if (selectedRole === 'siswa') {

                labelPilihan.textContent = 'NISN';

                input.placeholder = 'Ketik NISN di sini...';

            } else if (selectedRole === 'guru') {

                labelPilihan.textContent = 'NIP';

                input.placeholder = 'Ketik NIP di sini...';

            } else if (selectedRole === 'umum') {

                labelPilihan.textContent = 'Email';

                input.placeholder = 'Ketik Email di sini...';

            }

        });
    </script>
</body>

</html>